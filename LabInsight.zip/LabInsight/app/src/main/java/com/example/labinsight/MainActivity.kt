package com.example.labinsight

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val emailField = findViewById<EditText>(R.id.editTextTextEmailAddress2)
        val passwordField = findViewById<EditText>(R.id.editTextTextPassword2)
        val loginButton = findViewById<Button>(R.id.button)
        val recoverPasswordButton = findViewById<Button>(R.id.button2)


        loginButton.setOnClickListener {
            val email = emailField.text.toString()
            val password = passwordField.text.toString()

            // Verificar si el email y la contraseña son correctos
            if (email == "admin" && password == "admin") {
                // Navegar a pantalla2
                val intent = Intent(
                    this@MainActivity,
                    pantalla2::class.java
                )
                startActivity(intent)
            } else {
                // Mostrar un mensaje de error
                Toast.makeText(
                    this@MainActivity,
                    "Email o contraseña incorrectos",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        recoverPasswordButton.setOnClickListener {
            // Navegar a la pantalla de recuperación de contraseña
            val intent = Intent(this, RecuperarContrasenia::class.java)
            startActivity(intent)
        }
    }
}