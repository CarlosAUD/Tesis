package com.example.labinsight

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button

class crearusuario : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_crearusuario)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Configurar el botón de regresar
        val btnRegresar = findViewById<Button>(R.id.button11) // Asegúrate de que este ID corresponda con tu botón en el layout
        btnRegresar.setOnClickListener {
            val intent = Intent(this, AdministrarUsuarios::class.java)
            startActivity(intent)
            finish() // Esto cierra la actividad actual
        }
    }
}