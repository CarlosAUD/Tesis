package com.example.labinsight

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class RecuperarContrasenia : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_recuperar_contrasenia)

        // Configuración para el sistema de barras
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Botón "Regresar" (ID: boton13)
        val botonRegresar = findViewById<Button>(R.id.button13)
        botonRegresar.setOnClickListener {
            // Regresar a la MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()  // Finalizamos la actividad actual para que no quede en el stack
        }

        // Botón "Enviar" (ID: boton14)
        val botonEnviar = findViewById<Button>(R.id.button14)
        val editTextEmail = findViewById<EditText>(R.id.editTextTextEmailAddress3)

        botonEnviar.setOnClickListener {
            val correo = editTextEmail.text.toString().trim()

            // Validar si el correo está vacío
            if (correo.isEmpty()) {
                Toast.makeText(this, "Por favor ingresa un correo electrónico.", Toast.LENGTH_SHORT).show()
            }
            // Validar si el correo contiene espacios
            else if (correo.contains(" ")) {
                Toast.makeText(this, "El correo no puede contener espacios.", Toast.LENGTH_SHORT).show()
            }
            // Validar si el correo contiene más de un "@" o no tiene
            else if (correo.count { it == '@' } != 1) {
                Toast.makeText(this, "El correo debe contener solo un '@'.", Toast.LENGTH_SHORT).show()
            }
            // Validar longitud mínima de 5 caracteres
            else if (correo.length < 5) {
                Toast.makeText(this, "El correo debe tener al menos 5 caracteres.", Toast.LENGTH_SHORT).show()
            }
            // Validar si el correo contiene "@"
            else if (!correo.contains("@")) {
                Toast.makeText(this, "Por favor ingresa un correo válido.", Toast.LENGTH_SHORT).show()
            }
            else {
                // Si el correo es válido
                Toast.makeText(this, "Se envió la restauración al correo: $correo", Toast.LENGTH_SHORT).show()

                // Redirigir al usuario a la MainActivity
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()  // Finalizamos la actividad actual para que no quede en el stack
            }
        }
    }
}
