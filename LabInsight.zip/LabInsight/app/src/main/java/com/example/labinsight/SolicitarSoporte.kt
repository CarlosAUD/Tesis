package com.example.labinsight

import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.text.Spanned
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SolicitarSoporte : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_solicitar_soporte)

        // Inicializar las vistas
        val btnRegresar = findViewById<Button>(R.id.button7)
        val btnEnviar = findViewById<Button>(R.id.button10)
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroup)
        val etMaquina = findViewById<EditText>(R.id.maquina)
        val etInconveniente = findViewById<EditText>(R.id.inconveniente)

        // Configurar el filtro para el campo de máquina
        etMaquina.filters = arrayOf<InputFilter>(object : InputFilter {
            override fun filter(
                source: CharSequence?,
                start: Int,
                end: Int,
                dest: Spanned?,
                dstart: Int,
                dend: Int
            ): CharSequence? {
                try {
                    // Solo permitir dígitos
                    if (source?.matches(Regex("\\d*")) != true) {
                        return ""
                    }

                    // Construir el número resultante
                    val input = (dest.toString() + source.toString())
                    if (input.isEmpty()) return null

                    // Convertir a número y validar rango
                    val numero = input.toInt()
                    return if (numero in 1..50) null else ""
                } catch (e: NumberFormatException) {
                    return ""
                }
            }
        })

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Botón regresar
        btnRegresar.setOnClickListener {
            val intent = Intent(this, pantalla2::class.java)
            startActivity(intent)
            finish()
        }

        // Botón enviar con validaciones
        btnEnviar.setOnClickListener {
            if (validarFormulario(radioGroup, etMaquina, etInconveniente)) {
                // Aquí puedes agregar la lógica para enviar el formulario
                Toast.makeText(this, "Formulario enviado correctamente", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun validarFormulario(
        radioGroup: RadioGroup,
        etMaquina: EditText,
        etInconveniente: EditText
    ): Boolean {
        // Validar que se haya seleccionado una opción del RadioGroup
        if (radioGroup.checkedRadioButtonId == -1) {
            Toast.makeText(this, "Por favor seleccione una opción", Toast.LENGTH_SHORT).show()
            return false
        }

        // Validar que el campo máquina no esté vacío y sea un número válido entre 1 y 50
        val maquinaTexto = etMaquina.text.toString().trim()
        if (maquinaTexto.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese el número de la máquina", Toast.LENGTH_SHORT).show()
            return false
        }

        try {
            val numeroMaquina = maquinaTexto.toInt()
            if (numeroMaquina !in 1..50) {
                Toast.makeText(this, "El número de máquina debe estar entre 1 y 50", Toast.LENGTH_SHORT).show()
                return false
            }
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Por favor ingrese un número válido", Toast.LENGTH_SHORT).show()
            return false
        }

        // Validar el campo de inconveniente
        val inconvenienteTexto = etInconveniente.text.toString().trim()
        val letrasValidas = inconvenienteTexto.replace(Regex("[\\s.]"), "")

        if (letrasValidas.length < 4) {
            Toast.makeText(
                this,
                "El inconveniente debe tener al menos 4 letras sin contar espacios y puntos",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }

        return true
    }
}