package com.example.labinsight

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class AdministrarUsuarios : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_administrar_usuarios)

        // Configurar la navegación para el botón Regresar
        findViewById<Button>(R.id.regresar).setOnClickListener {
            val intent = Intent(this, pantalla2::class.java)
            startActivity(intent)
            finish() // Opcional: cierra esta actividad
        }

        // Configurar la navegación para el botón Crear
        findViewById<Button>(R.id.crear).setOnClickListener {
            val intent = Intent(this, crearusuario::class.java)
            startActivity(intent)
        }

        // Configurar la navegación para el botón Editar
        findViewById<Button>(R.id.editar).setOnClickListener {
            val intent = Intent(this, editarusuario::class.java)
            startActivity(intent)
        }

        // Configurar la navegación para el botón Eliminar
        findViewById<Button>(R.id.eliminar).setOnClickListener {
            val intent = Intent(this, eliminarusuario::class.java)
            startActivity(intent)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}